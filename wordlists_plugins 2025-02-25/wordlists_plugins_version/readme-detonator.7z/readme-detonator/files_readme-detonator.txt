wp-content/plugins/readme-detonator/index.php
wp-content/plugins/readme-detonator/languages/readme-detonator-pl_PL.mo
wp-content/plugins/readme-detonator/languages/readme-detonator-pl_PL.po
wp-content/plugins/readme-detonator/languages/wp-plugins-readme-detonator-dev-pl.mo
wp-content/plugins/readme-detonator/languages/wp-plugins-readme-detonator-dev-pl.po
wp-content/plugins/readme-detonator/readme-detonator.zip
wp-content/plugins/readme-detonator/readme.txt
wp-content/plugins/readme-detonator/style.css
