wp-content/plugins/readme-detonator/
wp-content/plugins/readme-detonator/languages/
