wp-content/plugins/wp-readme-parser/
wp-content/plugins/wp-readme-parser/assets/
wp-content/plugins/wp-readme-parser/includes/
wp-content/plugins/wp-readme-parser/includes/Michelf/
wp-content/plugins/wp-readme-parser/languages/
wp-content/plugins/wp-readme-parser/PHP Markdown Extra/
