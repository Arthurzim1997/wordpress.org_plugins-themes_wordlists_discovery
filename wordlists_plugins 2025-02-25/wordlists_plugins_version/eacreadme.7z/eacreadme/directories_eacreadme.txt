wp-content/plugins/eacreadme/
wp-content/plugins/eacreadme/Extensions/
wp-content/plugins/eacreadme/Extensions/parsedown-1.7.4/
wp-content/plugins/eacreadme/Extensions/prism/
wp-content/plugins/eacreadme/Extensions/vendor/
wp-content/plugins/eacreadme/Extensions/vendor/parsedown-1.7.4/
wp-content/plugins/eacreadme/Extensions/vendor/prism/
